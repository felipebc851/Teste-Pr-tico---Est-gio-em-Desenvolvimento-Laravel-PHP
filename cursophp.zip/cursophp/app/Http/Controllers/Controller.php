<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
class TtsController extends Controller
{
 public function index() {
 return view('tts');
1
 }
 public function speak(Request $request) {
 $request->validate(['text'=>'required']);
 $response = \\conseguir um api 
 'key' => env
 'hl' => 'pt-br',
 'src' => $request->text,
 'c' => 'MP3'

 $audio = base64_encode($response->body());
 return view('tts', ['audio' => $audio, 'texto'=>$request->text]);
 }
}