<form method="POST" action="/speak">
 @csrf
 <textarea name="text">{{ old('olá. este foi o Teste Prático - Estágio em Desenvolvimento Laravel + PHP. Feito po Felipe '') }}</textarea>
 <button type="submit">Falar</button>
</form>
@if(!empty($audio))
<audio controls>
 <source src=>
</audio>
@endif